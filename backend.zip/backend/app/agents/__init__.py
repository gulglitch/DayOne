# Agent implementations
